# HERA — Homelab Environment & Resource Assistant

> Your own self-hosted AI assistant for your homelab. Runs on your hardware,
> uses your local AI (or a cloud key as fallback), and configures itself from
> a clean web console. Built in public, episode by episode.

**Episode 1: the foundation** — a branded multi-view console (Dashboard, Chat,
Settings, Integrations) that talks to a local Ollama or a cloud API, with
automatic fallback. No homelab control yet — that's the next episodes.

## Features (Episode 1)
- 🖥️ **Rack-console web UI** — dashboard, chat, settings, integrations
- 🔌 **Bring your own AI** — local Ollama and/or cloud (OpenAI-compatible)
- ♻️ **Automatic fallback** — prefers local, falls back to cloud, reconnects to local
- ⚙️ **Configure from the UI** — add/test/prioritize providers, no file editing
- 🎨 **Rebrandable** — change the name and accent color in Settings
- 🐳 **Self-hostable** — one `docker compose up`

## Requirements
- Docker + Docker Compose
- An AI provider: a local [Ollama](https://ollama.com) instance and/or a cloud
  API key (OpenAI-compatible)

## Quick start
```bash
git clone https://github.com/YOURNAME/hera.git
cd hera
docker compose up -d --build
```
- Web console: `http://<host>:8080`
- Backend API: `http://<host>:8787`

Then open **Settings → AI Providers**, point HERA at your Ollama
(e.g. `http://YOUR-OLLAMA-IP:11434/v1`, model `qwen2.5:14b`), hit **Test**, save.
Add a cloud provider too if you want automatic fallback.

## Architecture
```
Web console  ──►  HERA backend (brain)  ──►  AI providers
(dashboard/chat/   /chat /settings /status     local Ollama  (priority 1)
 settings/integ)   /providers/test             cloud API     (fallback)
```
The backend is the brain; the web UI is its first client. Webhooks, mobile, and
homelab connectors (Proxmox, Docker) plug into the same brain in later episodes.

## Roadmap
- **Ep 1** — foundation: console + chat + provider config ✅
- **Ep 2** — HERA sees your homelab (read-only overview)
- **Ep 3** — Docker connector + safe actions (approval-gated)
- **Ep 4** — Proxmox connector (VMs, approval-gated)
- **Ep 5** — webhooks, dashboard sync, proactive alerts
- **Ep 6+** — memory, mobile, voice

## Safety principles
HERA never performs destructive actions without explicit approval. The AI
decides *what to propose*; connector code executes only *allowed* actions via
official APIs. If HERA is unsure, it asks before proceeding.

## License
MIT — fork it, rebrand it, make it yours.
